package com.rama77.app.model

data class BidHistoryItem(
    val id: String,
    val marketName: String,
    val gameType: String,
    val session: String,
    val digits: String,
    val points: Int,
    val status: String,
    val createdAt: String
)