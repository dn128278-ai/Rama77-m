package com.rama77.app.adapter

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.rama77.app.R
import com.rama77.app.databinding.ItemBidHistoryBinding
import com.rama77.app.model.BidHistoryItem

class HistoryAdapter(
    private var bids: List<BidHistoryItem>
) : RecyclerView.Adapter<HistoryAdapter.HistoryViewHolder>() {

    inner class HistoryViewHolder(val binding: ItemBidHistoryBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HistoryViewHolder {
        val binding = ItemBidHistoryBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return HistoryViewHolder(binding)
    }

    override fun onBindViewHolder(holder: HistoryViewHolder, position: Int) {
        val item = bids[position]
        with(holder.binding) {
            tvHistoryMarketName.text = item.marketName
            tvHistoryGameDetails.text = "${item.gameType} · ${item.session} (Ank: ${item.digits})"
            tvHistoryPoints.text = "₹${item.points}"
            tvHistoryDateTime.text = item.createdAt

            tvHistoryStatusBadge.text = item.status
            when (item.status.lowercase()) {
                "won", "win" -> {
                    tvHistoryStatusBadge.setTextColor(Color.parseColor("#16A34A"))
                    tvHistoryStatusBadge.setBackgroundColor(Color.parseColor("#DCFCE7"))
                }
                "lost", "loss" -> {
                    tvHistoryStatusBadge.setTextColor(Color.parseColor("#DC2626"))
                    tvHistoryStatusBadge.setBackgroundColor(Color.parseColor("#FEE2E2"))
                }
                else -> {
                    tvHistoryStatusBadge.setTextColor(Color.parseColor("#D97706"))
                    tvHistoryStatusBadge.setBackgroundColor(Color.parseColor("#FEF3C7"))
                }
            }
        }
    }

    override fun getItemCount(): Int = bids.size

    fun updateBids(newBids: List<BidHistoryItem>) {
        bids = newBids
        notifyDataSetChanged()
    }
}