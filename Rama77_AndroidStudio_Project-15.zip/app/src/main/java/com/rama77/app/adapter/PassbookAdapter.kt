package com.rama77.app.adapter

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.rama77.app.databinding.ItemPassbookTransactionBinding
import com.rama77.app.model.PassbookItem

class PassbookAdapter(
    private var transactions: List<PassbookItem>
) : RecyclerView.Adapter<PassbookAdapter.PassbookViewHolder>() {

    inner class PassbookViewHolder(val binding: ItemPassbookTransactionBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PassbookViewHolder {
        val binding = ItemPassbookTransactionBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return PassbookViewHolder(binding)
    }

    override fun onBindViewHolder(holder: PassbookViewHolder, position: Int) {
        val item = transactions[position]
        with(holder.binding) {
            tvTxTitle.text = "${item.title} | ${item.status.uppercase()}"
            tvTxAmountBadge.text = item.amount
            if (item.isCredit) {
                tvTxAmountBadge.setTextColor(Color.parseColor("#16A34A"))
            } else {
                tvTxAmountBadge.setTextColor(Color.parseColor("#DC2626"))
            }
            tvTxBalance.text = item.balance
            tvTxSubtitle.text = "${item.title} | TxId: ${item.id}"
            tvTxDate.text = item.date
            tvTxPrevBalance.text = "Previous Balance: ${item.prevBalance}"
        }
    }

    override fun getItemCount(): Int = transactions.size

    fun updateTransactions(newTransactions: List<PassbookItem>) {
        transactions = newTransactions
        notifyDataSetChanged()
    }
}