package com.rama77.app.ui.passbook

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.rama77.app.R
import com.rama77.app.adapter.PassbookAdapter
import com.rama77.app.databinding.FragmentPassbookBinding
import com.rama77.app.model.PassbookItem

class PassbookFragment : Fragment() {

    private var _binding: FragmentPassbookBinding? = null
    private val binding get() = _binding
    private lateinit var passbookAdapter: PassbookAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return try {
            _binding = FragmentPassbookBinding.inflate(inflater, container, false)
            binding?.root
        } catch (e: Throwable) {
            inflater.inflate(R.layout.fragment_passbook, container, false)
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        try {
            binding?.tvPassbookBalance?.text = "₹753"

            val transactions = listOf(
                PassbookItem("tx_9918", "Add Cash (PhonePe UPI)", "+₹500", true, "₹753", "₹253", "Success", "16 Oct 2026, 08:30 AM"),
                PassbookItem("tx_9842", "Winning Bid Credit (Single Digit)", "+₹950", true, "₹253", "₹0", "Success", "15 Oct 2026, 04:15 PM"),
                PassbookItem("tx_9721", "Bidding Debit (SRIDEVI)", "-₹100", false, "₹0", "₹100", "Success", "15 Oct 2026, 11:20 AM"),
                PassbookItem("tx_9614", "Withdrawal (Bank Transfer)", "-₹500", false, "₹100", "₹600", "Success", "14 Oct 2026, 06:40 PM"),
                PassbookItem("tx_9502", "Add Cash (Google Pay)", "+₹300", true, "₹600", "₹300", "Success", "14 Oct 2026, 10:15 AM")
            )

            passbookAdapter = PassbookAdapter(transactions)
            binding?.rvPassbook?.apply {
                layoutManager = LinearLayoutManager(context)
                adapter = passbookAdapter
            }

            binding?.btnPrevPage?.setOnClickListener {
                android.widget.Toast.makeText(context, "Page 1 of 1", android.widget.Toast.LENGTH_SHORT).show()
            }
        } catch (e: Throwable) {
            android.util.Log.e("PassbookFragment", "onViewCreated error: ${e.message}")
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}