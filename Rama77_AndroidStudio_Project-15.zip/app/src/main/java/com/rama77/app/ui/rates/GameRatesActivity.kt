package com.rama77.app.ui.rates

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.rama77.app.adapter.RateAdapter
import com.rama77.app.databinding.ActivityGameRatesBinding
import com.rama77.app.model.GameRateItem
import com.rama77.app.network.RetrofitClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class GameRatesActivity : AppCompatActivity() {

    private lateinit var binding: ActivityGameRatesBinding
    private lateinit var rama77Adapter: RateAdapter
    private lateinit var starlineAdapter: RateAdapter
    private lateinit var jackpotAdapter: RateAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGameRatesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRatesLists()
        fetchLiveRatesFromApi()
    }

    private fun setupRatesLists() {
        // 1. RAMA77 Game Win Ratio
        val defaultRamaRates = listOf(
            GameRateItem("Single Digit", "1 ka 9.5"),
            GameRateItem("Jodi Digit", "1 ka 95"),
            GameRateItem("Single Pana", "1 ka 150"),
            GameRateItem("Double Pana", "1 ka 300"),
            GameRateItem("Triple Pana", "1 ka 700"),
            GameRateItem("Half Sangam", "1 ka 1000"),
            GameRateItem("Full Sangam", "1 ka 10000")
        )
        rama77Adapter = RateAdapter(defaultRamaRates)
        binding.rvRama77Rates.layoutManager = LinearLayoutManager(this)
        binding.rvRama77Rates.adapter = rama77Adapter

        // 2. Bombay Starline Game Win Ratio
        val defaultStarlineRates = listOf(
            GameRateItem("Single Digit", "1 ka 9.5"),
            GameRateItem("Single Pana", "1 ka 150"),
            GameRateItem("Double Pana", "1 ka 300"),
            GameRateItem("Triple Pana", "1 ka 700")
        )
        starlineAdapter = RateAdapter(defaultStarlineRates)
        binding.rvStarlineRates.layoutManager = LinearLayoutManager(this)
        binding.rvStarlineRates.adapter = starlineAdapter

        // 3. Bombay Jackpot Game Win Ratio
        val defaultJackpotRates = listOf(
            GameRateItem("Jodi", "1 ka 95")
        )
        jackpotAdapter = RateAdapter(defaultJackpotRates)
        binding.rvJackpotRates.layoutManager = LinearLayoutManager(this)
        binding.rvJackpotRates.adapter = jackpotAdapter
    }

    private fun fetchLiveRatesFromApi() {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val response = RetrofitClient.apiService.getGameRates()
                if (response.isSuccessful && response.body()?.success == true) {
                    val remoteRates = response.body()?.data ?: emptyList()
                    if (remoteRates.isNotEmpty()) {
                        val mapped = remoteRates.map { GameRateItem(it.title, it.rate) }
                        withContext(Dispatchers.Main) {
                            rama77Adapter.updateRates(mapped)
                        }
                    }
                }
            } catch (e: Throwable) {
                // Fallback retains immediate rates safely without blanking
            }
        }
    }
}