package com.rama77.app.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.rama77.app.databinding.ItemGameRateBinding
import com.rama77.app.model.GameRateItem

class RateAdapter(
    private var rates: List<GameRateItem>
) : RecyclerView.Adapter<RateAdapter.RateViewHolder>() {

    inner class RateViewHolder(val binding: ItemGameRateBinding) :
        RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RateViewHolder {
        val binding = ItemGameRateBinding.inflate(
            LayoutInflater.from(parent.context), parent, false
        )
        return RateViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RateViewHolder, position: Int) {
        val item = rates[position]
        holder.binding.tvRateTitle.text = item.title
        holder.binding.tvRateValue.text = item.rate
    }

    override fun getItemCount(): Int = rates.size

    fun updateRates(newRates: List<GameRateItem>) {
        rates = newRates
        notifyDataSetChanged()
    }
}