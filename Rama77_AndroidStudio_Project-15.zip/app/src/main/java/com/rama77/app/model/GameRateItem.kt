package com.rama77.app.model

data class GameRateItem(
    val title: String,
    val rate: String
)