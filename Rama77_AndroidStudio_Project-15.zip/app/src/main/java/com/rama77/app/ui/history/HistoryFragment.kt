package com.rama77.app.ui.history

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.rama77.app.adapter.HistoryAdapter
import com.rama77.app.databinding.FragmentHistoryBinding
import com.rama77.app.model.BidHistoryItem
import com.rama77.app.network.model.UserBidHistoryDto
import com.rama77.app.network.RetrofitClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class HistoryFragment : Fragment() {

    private var _binding: FragmentHistoryBinding? = null
    private val binding get() = _binding
    private lateinit var historyAdapter: HistoryAdapter
    private val bidsList = mutableListOf<BidHistoryItem>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return try {
            _binding = FragmentHistoryBinding.inflate(inflater, container, false)
            binding?.root
        } catch (e: Throwable) {
            inflater.inflate(com.rama77.app.R.layout.fragment_history, container, false)
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupHistoryList()
        fetchLiveBidsFromApi()
    }

    private fun setupHistoryList() {
        val defaultBids = listOf(
            BidHistoryItem("101", "DEVI MORNING", "Single Digit", "Open", "6", 100, "Won", "16 Oct 2026, 09:15 AM"),
            BidHistoryItem("102", "SURYA MORNING", "Jodi Digit", "Close", "38", 50, "Lost", "16 Oct 2026, 10:45 AM"),
            BidHistoryItem("103", "SRIDEVI", "Single Pana", "Open", "147", 100, "Pending", "16 Oct 2026, 11:30 AM"),
            BidHistoryItem("104", "TIME BAZAR", "Single Digit", "Open", "3", 200, "Won", "16 Oct 2026, 12:50 PM"),
            BidHistoryItem("105", "MADHUR DAY", "Jodi Digit", "Open", "84", 75, "Pending", "16 Oct 2026, 01:15 PM")
        )

        bidsList.clear()
        bidsList.addAll(defaultBids)
        historyAdapter = HistoryAdapter(bidsList)

        binding?.rvBidsHistory?.apply {
            layoutManager = LinearLayoutManager(context)
            adapter = historyAdapter
        }
    }

    private fun fetchLiveBidsFromApi() {
        viewLifecycleOwner.lifecycleScope.launch(Dispatchers.IO) {
            try {
                val phone = "6377972674"
                val response = RetrofitClient.apiService.getUserBids(phone)
                if (response.isSuccessful && response.body()?.success == true) {
                    val remoteBids = response.body()?.data ?: emptyList()
                    if (remoteBids.isNotEmpty()) {
                        val mapped = remoteBids.map { dto ->
                            BidHistoryItem(
                                id = dto.id,
                                marketName = dto.marketName,
                                gameType = dto.gameType,
                                session = dto.session,
                                digits = dto.digits,
                                points = dto.points,
                                status = dto.status,
                                createdAt = dto.createdAt
                            )
                        }
                        withContext(Dispatchers.Main) {
                            historyAdapter.updateBids(mapped)
                        }
                    }
                }
            } catch (e: Throwable) {
                // Default immediate list displayed safely
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}