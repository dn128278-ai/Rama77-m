package com.rama77.app.model

data class PassbookItem(
    val id: String,
    val title: String,
    val amount: String,
    val isCredit: Boolean,
    val balance: String,
    val prevBalance: String,
    val status: String,
    val date: String
)